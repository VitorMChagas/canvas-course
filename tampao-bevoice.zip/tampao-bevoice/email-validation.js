function ValidateEmail(inputText)
{

if(inputText.value.match(mailformat))
{
alert("Valid email address!");
document.emailform.email.focus();
return true;
}
else
{
alert("You have entered an invalid email address!");
document.emailform.email.focus();
return false;
}
}